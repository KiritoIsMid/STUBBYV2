Python must be installed!
Internet connection must be available!
Disable your antivirus/defender!

Run "Builder.bat"
